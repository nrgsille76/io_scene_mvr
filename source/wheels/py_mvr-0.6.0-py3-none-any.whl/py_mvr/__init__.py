from typing import List, Union, Optional
from xml.etree import ElementTree
from xml.etree.ElementTree import Element
import zipfile
import sys
import uuid as py_uuid
from .value import Matrix, Color  # type: ignore

__version__ = "0.6.0"


def _find_root(pkg: "zipfile.ZipFile") -> "ElementTree.Element":
    """Given a GDTF zip archive, find the GeneralSceneDescription of the
    corresponding GeneralSceneDescription.xml file."""

    with pkg.open("GeneralSceneDescription.xml", "r") as f:
        description_str = f.read().decode("UTF-8")
        if description_str[-1] == "\x00":  # this should not happen, but...
            description_str = description_str[:-1]
    return ElementTree.fromstring(description_str)


class GeneralSceneDescription:
    def __init__(self, path=None):
        if path is not None:
            self._package = zipfile.ZipFile(path, "r")
        if self._package is not None:
            self._root = _find_root(self._package)
            self._user_data = self._root.find("UserData")
            self._scene = self._root.find("Scene")
        if self._root is not None:
            self._read_xml()

    def _read_xml(self):
        self.version_major: str = self._root.get("verMajor", "")
        self.version_minor: str = self._root.get("verMinor", "")
        self.provider: str = self._root.get("provider", "")
        self.providerVersion: str = self._root.get("providerVersion", "")

        layers_collect = self._scene.find("Layers")
        if layers_collect is not None:
            self.layers: List["Layer"] = [Layer(xml_node=i) for i in layers_collect.findall("Layer")]
        else:
            self.layers = []

        aux_data_collect = self._scene.find("AUXData")
        if aux_data_collect is not None:
            self.aux_data = AUXData(xml_node=aux_data_collect)
        else:
            self.aux_data = None
        if self._user_data is not None:
            self.user_data: List["Data"] = [Data(xml_node=i) for i in self._user_data.findall("Data")]


class GeneralSceneDescriptionWriter:
    """Creates MVR zip archive with packed GeneralSceneDescription xml and other files"""

    # maybe we should split/rename this into xml creator and mvr creator
    def __init__(self):
        self.version_major: str = "1"
        self.version_minor: str = "6"
        self.provider: str = "pyMVR"
        self.provider_version: str = __version__
        self.files_list: List[Tuple[str, str]] = []
        self.xml_root = ElementTree.Element("GeneralSceneDescription", verMajor=self.version_major, verMinor=self.version_minor,
                                            provider=self.provider, provider_version=self.provider_version)

    def write_mvr(self, path=None):
        if path is not None:
            if sys.version_info >= (3, 9):
                ElementTree.indent(self.xml_root, space="    ", level=0)
            xmlstr = ElementTree.tostring(self.xml_root, encoding="unicode")
            declaration = '<?xml version="1.0" encoding="UTF-8" standalone="no" ?>\n'
            full_xml = declaration + xmlstr
            with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
                z.writestr("GeneralSceneDescription.xml", full_xml)
                for file_path, file_name in self.files_list:
                    try:
                        z.write(file_path, arcname=file_name)
                    except Exception as e:
                        print(f"File does not exist {file_path}")


class SceneElement:
    def to_xml(self, parent: Element):
        return ElementTree.SubElement(parent, "Scene")


class LayersElement:
    def to_xml(self, parent: Element):
        return ElementTree.SubElement(parent, "Layers")


class UserData:
    def to_xml(self, parent: Element):
        return ElementTree.SubElement(parent, "UserData")


class BaseNode:
    def __init__(self, xml_node: "Element" = None):
        if xml_node is not None:
            self._read_xml(xml_node)

    def _read_xml(self, xml_node: "Element"):
        pass


class BaseChildNode(BaseNode):
    def __init__(
        self,
        name: Optional[str] = None,
        uuid: Optional[str] = None,
        gdtf_spec: Optional[str] = None,
        gdtf_mode: Optional[str] = None,
        matrix: Matrix = Matrix(0),
        classing: Optional[str] = None,
        fixture_id: Optional[str] = None,
        fixture_id_numeric: int = 0,
        unit_number: int = 0,
        fixture_type_id: int = 0,
        custom_id: int = 0,
        custom_id_type: int = 0,
        cast_shadow: bool = False,
        addresses: List["Address"] = [],
        alignments: List["Alignment"] = [],
        custom_commands: List["CustomCommand"] = [],
        overwrites: List["Overwrite"] = [],
        connections: List["Connection"] = [],
        child_list: Union["ChildList", None] = None,
        multipatch: Optional[str] = None,
        *args,
        **kwargs,
    ):
        self.name = name
        if uuid is None:
            uuid = str(py_uuid.uuid4())
        self.uuid = uuid
        self.gdtf_spec = gdtf_spec
        self.gdtf_mode = gdtf_mode
        self.matrix = matrix
        self.classing = classing
        self.fixture_id = fixture_id
        self.fixture_id_numeric = fixture_id_numeric
        self.unit_number = unit_number
        self.fixture_type_id = fixture_type_id
        self.custom_id = custom_id
        self.custom_id_type = custom_id_type
        self.cast_shadow = cast_shadow
        self.addresses = addresses
        self.alignments = alignments
        self.custom_commands = custom_commands
        self.overwrites = overwrites
        self.connections = connections
        self.child_list = child_list
        self.multipatch = multipatch
        super().__init__(*args, **kwargs)

    def _read_xml(self, xml_node: "Element"):
        self.name = xml_node.attrib.get("name", "")
        self.uuid = xml_node.attrib.get("uuid")
        _gdtf_spec = xml_node.find("GDTFSpec")
        self.multipatch = xml_node.attrib.get("multipatch")
        if _gdtf_spec is not None:
            self.gdtf_spec = _gdtf_spec.text
            if self.gdtf_spec is not None:
                self.gdtf_spec = self.gdtf_spec.encode("utf-8").decode("cp437")  # IBM PC encoding
            if self.gdtf_spec is not None and len(self.gdtf_spec) > 5:
                if self.gdtf_spec[-5:].lower() != ".gdtf":
                    self.gdtf_spec = f"{self.gdtf_spec}.gdtf"
        if xml_node.find("GDTFMode") is not None:
            self.gdtf_mode = xml_node.find("GDTFMode").text
        if xml_node.find("Matrix") is not None:
            self.matrix = Matrix(str_repr=xml_node.find("Matrix").text)
        if xml_node.find("FixtureID") is not None:
            self.fixture_id = xml_node.find("FixtureID").text
        if xml_node.find("FixtureIDNumeric") is not None:
            self.fixture_id_numeric = int(xml_node.find("FixtureIDNumeric").text)
        if xml_node.find("UnitNumber") is not None:
            self.unit_number = int(xml_node.find("UnitNumber").text)
        if xml_node.find("FixtureTypeId") is not None:
            self.fixture_type_id = int(xml_node.find("FixtureTypeId").text or 0)
        if xml_node.find("CustomId") is not None:
            self.custom_id = int(xml_node.find("CustomId").text or 0)
        if xml_node.find("CustomIdType") is not None:
            self.custom_id_type = int(xml_node.find("CustomIdType").text or 0)
        if xml_node.find("CastShadow") is not None:
            self.cast_shadow = bool(xml_node.find("CastShadow").text)
        if xml_node.find("Addresses") is not None:
            self.addresses = [Address(xml_node=i) for i in xml_node.find("Addresses").findall("Address")]
        if not len(self.addresses):
            self.addresses = [Address(dmx_break=0, universe=0, address=0)]
        if xml_node.find("Alignments"):
            self.alignments = [Alignment(xml_node=i) for i in xml_node.find("Alignments").findall("Alignment")]
        if xml_node.find("Connections"):
            self.connections = [Connection(xml_node=i) for i in xml_node.find("Connections").findall("Connection")]
        if xml_node.find("CustomCommands") is not None:
            self.custom_commands = [CustomCommand(xml_node=i) for i in xml_node.find("CustomCommands").findall("CustomCommand")]
        if xml_node.find("Overwrites"):
            self.overwrites = [Overwrite(xml_node=i) for i in xml_node.find("Overwrites").findall("Overwrite")]
        if xml_node.find("Classing") is not None:
            self.classing = xml_node.find("Classing").text
        self.child_list = ChildList(xml_node=xml_node.find("ChildList"))

    def __str__(self):
        return f"{self.name}"


class BaseChildNodeExtended(BaseChildNode):
    def __init__(
        self,
        geometries: "Geometries" = None,
        child_list: Union["ChildList", None] = None,
        *args,
        **kwargs,
    ):
        self.geometries = geometries
        self.child_list = child_list
        super().__init__(*args, **kwargs)

    def _read_xml(self, xml_node: "Element"):
        super()._read_xml(xml_node)
        if xml_node.find("Geometries") is not None:
            self.geometries = Geometries(xml_node=xml_node.find("Geometries"))
        self.child_list = ChildList(xml_node=xml_node.find("ChildList"))

    def __str__(self):
        return f"{self.name}"


class Data(BaseNode):
    def __init__(
        self,
        provider: str = "NRGSille",
        ver: str = "1.0.0",
        *args,
        **kwargs,
    ):
        self.provider = provider
        self.ver = ver
        super().__init__(*args, **kwargs)

    def _read_xml(self, xml_node: "Element"):
        provider = xml_node.attrib.get("provider")
        if provider is not None:
            self.provider = provider
        ver = xml_node.attrib.get("ver")
        if ver is not None:
            self.ver = ver

    def __str__(self):
        return f"{self.provider} {self.ver}"

    def to_xml(self, parent: Element):
        return ElementTree.SubElement(parent, type(self).__name__, provider=self.provider, ver=self.ver)


class AUXData(BaseNode):
    def __init__(
        self,
        classes: List["Class"] = [],
        symdefs: List["Symdef"] = [],
        positions: List["Position"] = [],
        mapping_definitions: List["MappingDefinition"] = [],
        *args,
        **kwargs,
    ):
        self.classes = classes
        self.symdefs = symdefs
        self.positions = positions
        self.mapping_definitions = mapping_definitions
        super().__init__(*args, **kwargs)

    def _read_xml(self, xml_node: "Element"):
        self.classes = [Class(xml_node=i) for i in xml_node.findall("Class")]
        self.symdefs = [Symdef(xml_node=i) for i in xml_node.findall("Symdef")]
        self.positions = [Position(xml_node=i) for i in xml_node.findall("Position")]
        self.mapping_definitions = [MappingDefinition(xml_node=i) for i in xml_node.findall("MappingDefinition")]

    def to_xml(self, parent: Element):
        element = ElementTree.SubElement(parent, type(self).__name__)
        for cls in self.classes:
            element.append(cls)
        for symdef in self.symdefs:
            element.append(symdef)
        return element


class MappingDefinition(BaseNode):
    def __init__(
        self,
        name: str = "",
        uuid: Optional[str] = None,
        size_x: int = 0,
        size_y: int = 0,
        source=None,
        scale_handling=None,
        *args,
        **kwargs,
    ):
        self.name = name
        if uuid is None:
            uuid = str(py_uuid.uuid4())
        self.uuid = uuid
        self.size_x = size_x
        self.size_y = size_y
        self.source = source
        self.scale_handling = scale_handling
        super().__init__(*args, **kwargs)

    def _read_xml(self, xml_node: "Element"):
        # TODO handle missing data...
        self.size_x = int(xml_node.find("SizeX").text)
        self.size_y = int(xml_node.find("SizeY").text)
        self.source = xml_node.find("Source")  # TODO
        self.scale_handling = xml_node.find("ScaleHandeling").text  # TODO ENUM


class Fixture(BaseChildNode):
    def __init__(
        self,
        focus: Optional[str] = None,
        color: Union["Color", str, None] = Color(),
        dmx_invert_pan: bool = False,
        dmx_invert_tilt: bool = False,
        position: Optional[str] = None,
        function_: Optional[str] = None,
        child_position: Optional[str] = None,
        protocols: Optional["Protocol"] = None,
        mappings: Optional["Mapping"] = None,
        gobo: Optional["Gobo"] = None,
        *args,
        **kwargs,
    ):
        self.focus = focus
        self.color = color
        self.dmx_invert_pan = dmx_invert_pan
        self.dmx_invert_tilt = dmx_invert_tilt
        self.position = position
        self.function_ = function_
        self.child_position = child_position
        self.protocols = protocols
        self.mappings = mappings
        self.gobo = gobo
        super().__init__(*args, **kwargs)

    def _read_xml(self, xml_node: "Element"):
        super()._read_xml(xml_node)
        if xml_node.attrib.get("multipatch") is not None:
            self.multipatch = xml_node.attrib.get("multipatch")
        if xml_node.find("Focus") is not None:
            self.focus = xml_node.find("Focus").text
        if xml_node.find("Color") is not None:
            self.color = Color(str_repr=xml_node.find("Color").text)
        if xml_node.find("DMXInvertPan") is not None:
            self.dmx_invert_pan = bool(xml_node.find("DMXInvertPan").text)
        if xml_node.find("DMXInvertTilt") is not None:
            self.dmx_invert_tilt = bool(xml_node.find("DMXInvertTilt").text)
        if xml_node.find("Position") is not None:
            self.position = xml_node.find("Position").text
        if xml_node.find("Function") is not None:
            self.function_ = xml_node.find("Position").text
        if xml_node.find("ChildPosition") is not None:
            self.child_position = xml_node.find("ChildPosition").text
        if xml_node.find("Protocols"):
            self.protocols = [Protocol(xml_node=i) for i in xml_node.find("Protocols").findall("Protocol")]
        if xml_node.find("Mappings") is not None:
            self.mappings = [Mapping(xml_node=i) for i in xml_node.find("Mappings").findall("Mapping")]
        if xml_node.find("Gobo") is not None:
            self.gobo = Gobo(xml_node.attrib.get("Gobo"))

    def to_xml(self):
        fixture_element = ElementTree.Element(type(self).__name__, name=self.name, uuid=self.uuid)
        Matrix(self.matrix.matrix).to_xml(fixture_element)
        ElementTree.SubElement(fixture_element, "GDTFSpec").text = self.gdtf_spec
        ElementTree.SubElement(fixture_element, "GDTFMode").text = self.gdtf_mode
        if self.focus is not None:
            ElementTree.SubElement(fixture_element, "Focus").text = self.focus
        ElementTree.SubElement(fixture_element, "FixtureID").text = self.fixture_id or "0"
        ElementTree.SubElement(fixture_element, "FixtureIDNumeric").text = str(self.fixture_id_numeric)
        ElementTree.SubElement(fixture_element, "UnitNumber").text = str(self.unit_number)
        ElementTree.SubElement(fixture_element, "Classing").text = str(self.classing)
        if self.custom_id:
            ElementTree.SubElement(fixture_element, "CustomId").text = str(self.custom_id)
        if self.custom_id_type:
            ElementTree.SubElement(fixture_element, "CustomIdType").text = str(self.custom_id_type)
        if isinstance(self.color, Color):
            self.color.to_xml(fixture_element)
        else:
            Color(str_repr=self.color).to_xml(fixture_element)
        addresses = ElementTree.SubElement(fixture_element, "Addresses")
        for address in self.addresses:
            Address(address.dmx_break, address.universe, address.address).to_xml(addresses)
        if self.classing:
            ElementTree.SubElement(fixture_element, "Classing").text = self.classing

        return fixture_element

    def __str__(self):
        return f"{self.name}"


class GroupObject(BaseNode):
    def __init__(
        self,
        name: str = "",
        uuid: Optional[str] = None,
        classing: Optional[str] = None,
        child_list: Union["ChildList", None] = None,
        matrix: Matrix = Matrix(0),
        *args,
        **kwargs,
    ):
        self.name = name
        if uuid is None:
            uuid = str(py_uuid.uuid4())
        self.uuid = uuid
        self.classing = classing
        self.child_list = child_list
        self.matrix = matrix

        super().__init__(*args, **kwargs)

    def _read_xml(self, xml_node: "Element"):
        self.name = xml_node.attrib.get("name")
        self.uuid = xml_node.attrib.get("uuid")
        classing_node = xml_node.find("Classing")
        if classing_node is not None:
            self.classing = classing_node.text
        self.child_list = ChildList(xml_node=xml_node.find("ChildList"))
        if xml_node.find("Matrix") is not None:
            self.matrix = Matrix(str_repr=xml_node.find("Matrix").text)

    def __str__(self):
        return f"{self.name}"

    def to_xml(self):
        element = ElementTree.Element(type(self).__name__, name=self.name, uuid=self.uuid)
        if self.classing:
            ElementTree.SubElement(element, "Classing").text = self.classing

        return element


class ChildList(BaseNode):
    def __init__(
        self,
        scene_objects: List["SceneObject"] = [],
        group_objects: List["GroupObject"] = [],
        focus_points: List["FocusPoint"] = [],
        fixtures: List["Fixture"] = [],
        supports: List["Support"] = [],
        trusses: List["Truss"] = [],
        video_screens: List["VideoScreen"] = [],
        projectors: List["Projector"] = [],
        *args,
        **kwargs,
    ):
        self.scene_objects = scene_objects if scene_objects is not None else []
        self.group_objects = group_objects if group_objects is not None else []
        self.focus_points = focus_points if focus_points is not None else []
        self.fixtures = fixtures if fixtures is not None else []
        self.supports = supports if supports is not None else []
        self.video_screens = video_screens if video_screens is not None else []
        self.trusses = trusses if trusses is not None else []
        self.projectors = projectors if projectors is not None else []

        super().__init__(*args, **kwargs)

    def _read_xml(self, xml_node: "Element"):
        self.scene_objects = [SceneObject(xml_node=i) for i in xml_node.findall("SceneObject")]
        self.group_objects = [GroupObject(xml_node=i) for i in xml_node.findall("GroupObject")]
        self.focus_points = [FocusPoint(xml_node=i) for i in xml_node.findall("FocusPoint")]
        self.fixtures = [Fixture(xml_node=i) for i in xml_node.findall("Fixture")]
        self.supports = [Support(xml_node=i) for i in xml_node.findall("Support")]
        self.trusses = [Truss(xml_node=i) for i in xml_node.findall("Truss")]
        self.video_screens = [VideoScreen(xml_node=i) for i in xml_node.findall("VideoScreen")]
        self.projectors = [Projector(xml_node=i) for i in xml_node.findall("Projector")]

    def to_xml(self, parent: Element):
        element = ElementTree.SubElement(parent, type(self).__name__)
        for fixture in self.fixtures:
            element.append(fixture)
        for focus_point in self.focus_points:
            element.append(focus_point)
        for group_object in self.group_objects:
            element.append(group_object)
        for scene_object in self.scene_objects:
            element.append(scene_object)
        for support in self.supports:
            element.append(support)
        for truss in self.trusses:
            element.append(truss)
        for video_screen in self.video_screens:
            element.append(video_screen)
        for projector in self.projectors:
            element.append(projector)
        return element



class Layer(BaseNode):
    def __init__(
        self,
        name: str = "",
        uuid: Optional[str] = None,
        gdtf_spec: Optional[str] = None,
        gdtf_mode: Optional[str] = None,
        child_list: Union["ChildList", None] = None,
        matrix: Matrix = Matrix(0),
        *args,
        **kwargs,
    ):
        self.name = name
        if uuid is None:
            uuid = str(py_uuid.uuid4())
        self.uuid = uuid
        self.gdtf_spec = gdtf_spec
        self.gdtf_mode = gdtf_mode
        self.child_list = child_list
        self.matrix = matrix

        super().__init__(*args, **kwargs)

    def _read_xml(self, xml_node: "Element"):
        self.name = xml_node.attrib.get("name")
        self.uuid = xml_node.attrib.get("uuid")
        self.child_list = ChildList(xml_node=xml_node.find("ChildList"))
        if xml_node.find("Matrix") is not None:
            self.matrix = Matrix(str_repr=xml_node.find("Matrix").text)

    def __str__(self):
        return f"{self.name}"

    def to_xml(self, parent: Element):
        return ElementTree.SubElement(parent, type(self).__name__, name=self.name, uuid=self.uuid)


class Address(BaseNode):
    def __init__(
        self,
        dmx_break: int = 0,
        universe: int = 1,
        address: int = 1,
        *args,
        **kwargs,
    ):
        self.dmx_break = dmx_break
        self.address = address
        self.universe = universe
        super().__init__(*args, **kwargs)

    def _read_xml(self, xml_node: "Element"):
        self.dmx_break = int(xml_node.attrib.get("break", 0))
        raw_address = xml_node.text or "1"
        if raw_address == "0":
            raw_address = "1"
        if "." in raw_address:
            universe, address = raw_address.split(".")
            self.universe = int(universe) if (int(universe)) > 0 else 1
            self.address = int(address) if int(address) > 0 else 1
            return
        self.universe = (int(raw_address) - 1) // 512 + 1
        self.address = (int(raw_address) - 1) % 512 + 1

    def __repr__(self):
        return f"B: {self.dmx_break}, U: {self.universe}, A: {self.address}"

    def __str__(self):
        return f"B: {self.dmx_break}, U: {self.universe}, A: {self.address}"

    def to_xml(self, addresses):
        # universes are always from 1 in MVR
        if self.universe == 0:
            self.universe = 1
        universes = 512 * (self.universe - 1)
        raw_address = self.address + universes
        address = ElementTree.SubElement(addresses, "Address", attrib={"break": str(self.dmx_break)})
        address.text = str(raw_address)


class Class(BaseNode):
    def __init__(
        self,
        uuid: Optional[str] = None,
        name: Optional[str] = None,
        *args,
        **kwargs,
    ):
        self.uuid = uuid
        self.name = name
        super().__init__(*args, **kwargs)

    def _read_xml(self, xml_node: "Element"):
        self.name = xml_node.attrib.get("name")
        self.uuid = xml_node.attrib.get("uuid")

    def __str__(self):
        return f"{self.name}"

    def to_xml(self):
        return ElementTree.Element(type(self).__name__, name=self.name, uuid=self.uuid)


class Position(BaseNode):
    def __init__(
        self,
        uuid: Optional[str] = None,
        name: Optional[str] = None,
        *args,
        **kwargs,
    ):
        self.uuid = uuid
        self.name = name
        super().__init__(*args, **kwargs)

    def _read_xml(self, xml_node: "Element"):
        self.name = xml_node.attrib.get("name")
        self.uuid = xml_node.attrib.get("uuid")

    def __str__(self):
        return f"{self.name}"

    def to_xml(self):
        return ElementTree.Element(type(self).__name__, name=self.name, uuid=self.uuid)



class Symdef(BaseNode):
    def __init__(
        self,
        name: str = "",
        uuid: Optional[str] = None,
        geometry3d: List["Geometry3D"] = [],
        symbol: List["Symbol"] = [],
        xml_node: Optional["Element"] = None,
        *args,
        **kwargs,
    ):
        self.name = name
        if uuid is None:
            uuid = str(py_uuid.uuid4())
        self.uuid = uuid
        self.geometry3d = geometry3d
        self.symbol = symbol
        super().__init__(xml_node, *args, **kwargs)

    def _read_xml(self, xml_node: "Element"):
        self.name = xml_node.attrib.get("name")
        self.uuid = xml_node.attrib.get("uuid")
        child_list = xml_node.find("ChildList")
        if child_list is not None:
            self.symbol = [Symbol(xml_node=i) for i in child_list.findall("Symbol")]
            _geometry3d = [Geometry3D(xml_node=i) for i in child_list.findall("Geometry3D")]
        else:
            self.symbol = []
            _geometry3d = []

        # sometimes the list of geometry3d is full of duplicates, eliminate them here
        self.geometry3d = list(set(_geometry3d))

    def to_xml(self):
        element = ElementTree.Element(type(self).__name__, name=self.name, uuid=self.uuid)
        for geo in self.geometry3d:
            element.append(geo.to_xml())
        for sym in self.symbol:
            element.append(sym.to_xml())
        return element


class Geometry3D(BaseNode):
    def __init__(
        self,
        file_name: str = "",
        matrix: Matrix = Matrix(0),
        *args,
        **kwargs,
    ):
        self.file_name = file_name
        self.matrix = matrix
        super().__init__(*args, **kwargs)

    def _read_xml(self, xml_node: "Element"):
        self.file_name = xml_node.attrib.get("fileName").encode("utf-8").decode("cp437")
        if xml_node.find("Matrix") is not None:
            self.matrix = Matrix(str_repr=xml_node.find("Matrix").text)

    def __str__(self):
        return f"{self.file_name} {self.matrix}"

    def __repr__(self):
        return f"{self.file_name} {self.matrix}"

    def __eq__(self, other):
        return self.file_name == other.file_name and self.matrix == other.matrix

    def __ne__(self, other):
        return self.file_name != other.file_name or self.matrix != other.matrix

    def __hash__(self):
        return hash((self.file_name, str(self.matrix)))

    def to_xml(self):
        return ElementTree.Element(type(self).__name__, fileName=self.file_name)


class Symbol(BaseNode):
    def __init__(
        self,
        symdef: Optional[str] = None,
        uuid: Optional[str] = None,
        matrix: Matrix = Matrix(0),
        *args,
        **kwargs,
    ):
        self.symdef = symdef
        if uuid is None:
            uuid = str(py_uuid.uuid4())
        self.uuid = uuid
        self.matrix = matrix
        super().__init__(*args, **kwargs)

    def _read_xml(self, xml_node: "Element"):
        self.symdef = xml_node.attrib.get("symdef")
        self.uuid = xml_node.attrib.get("uuid")
        if xml_node.find("Matrix") is not None:
            self.matrix = Matrix(str_repr=xml_node.find("Matrix").text)

    def __repr__(self):
        return f"{self.symdef}"

    def __str__(self):
        return f"{self.uuid}"

    def to_xml(self):
        return ElementTree.Element(type(self).__name__, symdef=self.symdef, uuid=self.uuid)


class Geometries(BaseNode):
    def __init__(
        self,
        geometry3d: List["Geometry3D"] = [],
        symbol: List["Symbol"] = [],
        *args,
        **kwargs,
    ):
        self.geometry3d = geometry3d
        self.symbol = symbol
        super().__init__(*args, **kwargs)

    def _read_xml(self, xml_node: "Element"):
        self.symbol = [Symbol(xml_node=i) for i in xml_node.findall("Symbol")]
        self.geometry3d = [Geometry3D(xml_node=i) for i in xml_node.findall("Geometry3D")]
        if xml_node.find("ChildList"):
            child_list = xml_node.find("ChildList")
            symbols = [Symbol(xml_node=i) for i in child_list.findall("Symbol")]
            geometry3ds = [Geometry3D(xml_node=i) for i in child_list.findall("Geometry3D")]
            self.symbol += symbols  # TODO remove this over time, children should only be in child_list
            self.geometry3d += geometry3ds

    def to_xml(self, parent: Element):
        element = ElementTree.SubElement(parent, type(self).__name__)
        for geo in self.geometry3d:
            element.append(geo.to_xml())
        for sym in self.symbol:
            element.append(sym.to_xml())

        return element


class FocusPoint(BaseNode):
    def __init__(
        self,
        name: str = "",
        uuid: Optional[str] = None,
        matrix: Matrix = Matrix(0),
        classing: Optional[str] = None,
        geometries: Optional["Geometries"] = None,
        *args,
        **kwargs,
    ):
        self.name = name
        if uuid is None:
            uuid = str(py_uuid.uuid4())
        self.uuid = uuid
        self.matrix = matrix
        self.classing = classing
        if geometries is None:
            geometries = Geometries()
        self.geometries = geometries

        super().__init__(*args, **kwargs)

    def _read_xml(self, xml_node: "Element"):
        self.uuid = xml_node.attrib.get("uuid")
        self.name = xml_node.attrib.get("name")
        matrix_node = xml_node.find("Matrix")
        if matrix_node is not None and matrix_node.text is not None:
            self.matrix = Matrix(str_repr=matrix_node.text)
        classing_node = xml_node.find("Classing")
        if classing_node is not None:
            self.classing = classing_node.text
        geometries_node = xml_node.find("Geometries")
        if geometries_node is not None:
            self.geometries = Geometries(xml_node=geometries_node)

    def __str__(self):
        return f"{self.name}"

    def to_xml(self):
        element = ElementTree.Element(type(self).__name__, name=self.name, uuid=self.uuid)
        Matrix(self.matrix.matrix).to_xml(parent=element)
        if self.classing:
            ElementTree.SubElement(element, "Classing").text = self.classing

        return element


class SceneObject(BaseChildNodeExtended):
    def to_xml(self):
        attributes = {"name": self.name, "uuid": self.uuid}
        element = ElementTree.Element(type(self).__name__, attributes)
        Matrix(self.matrix.matrix).to_xml(parent=element)
        if self.classing:
            ElementTree.SubElement(element, "Classing").text = self.classing

        return element


class Truss(BaseChildNodeExtended):
    def to_xml(self):
        attributes = {"name": self.name, "uuid": self.uuid}
        element = ElementTree.Element(type(self).__name__, attributes)
        Matrix(self.matrix.matrix).to_xml(parent=element)
        if self.classing:
            ElementTree.SubElement(element, "Classing").text = self.classing

        return element


class Support(BaseChildNodeExtended):
    def __init__(
        self,
        chain_length: float = 0,
        *args,
        **kwargs,
    ):
        self.chain_length = chain_length
        super().__init__(*args, **kwargs)

    def _read_xml(self, xml_node: "Element"):
        super()._read_xml(xml_node)
        if chain_length_node is not None and chain_length_node.text is not None:
            self.chain_length = float(chain_length_node.text or 0)

    def to_xml(self):
        attributes = {"name": self.name, "uuid": self.uuid}
        element = ElementTree.Element(type(self).__name__, attributes)
        ElementTree.SubElement(element, "ChainLength").text = str(self.chain_length)
        Matrix(self.matrix.matrix).to_xml(parent=element)
        if self.classing:
            ElementTree.SubElement(element, "Classing").text = self.classing

        return element


class VideoScreen(BaseChildNodeExtended):
    def __init__(
        self,
        sources: Optional["Sources"] = None,
        *args,
        **kwargs,
    ):
        self.sources = sources
        super().__init__(*args, **kwargs)

    def _read_xml(self, xml_node: "Element"):
        super()._read_xml(xml_node)
        sources_node = xml_node.find("Sources")
        if sources_node is not None:
            self.sources = Sources(xml_node=sources_node)

    def to_xml(self):
        attributes = {"name": self.name, "uuid": self.uuid}
        element = ElementTree.Element(type(self).__name__, attributes)
        if self.sources:
            self.sources.to_xml(element)
        if self.classing:
            ElementTree.SubElement(element, "Classing").text = self.classing

        return element


class Projector(BaseChildNodeExtended):
    def __init__(
        self,
        projections: Optional["Projections"] = None,
        *args,
        **kwargs,
    ):
        self.projections = projections
        super().__init__(*args, **kwargs)

    def _read_xml(self, xml_node: "Element"):
        super()._read_xml(xml_node)
        projections_node = xml_node.find("Projections")
        if projections_node is not None:
            self.projections = Projections(xml_node=projections_node)

    def to_xml(self):
        attributes = {"name": self.name, "uuid": self.uuid}
        element = ElementTree.Element(type(self).__name__, attributes)
        if self.projections:
            self.projections.to_xml(element)
        if self.classing:
            ElementTree.SubElement(element, "Classing").text = self.classing

        return element


class Protocol(BaseNode):
    def __init__(
        self,
        name: str = "",
        geometry: Optional[str] = None,
        type_: Optional[str] = None,
        version: Optional[str] = None,
        transmission: Optional[str] = None,
        *args,
        **kwargs,
    ):
        self.name = name
        self.geometry = geometry
        self.type = type_
        self.version = version
        self.transmission = transmission
        super().__init__(*args, **kwargs)

    def _read_xml(self, xml_node: "Element"):
        self.geometry = xml_node.attrib.get("geometry")
        self.name = xml_node.attrib.get("name")
        self.type = xml_node.attrib.get("type")
        self.version = xml_node.attrib.get("version")
        self.transmission = xml_node.attrib.get("transmission")

    def __str__(self):
        return f"{self.name}"

    def to_xml(self):
        attributes = {}
        if self.geometry:
            attributes["geometry"] = self.geometry
        if self.name:
            attributes["name"] = self.name
        if self.type:
            attributes["type"] = self.type
        if self.version:
            attributes["version"] = self.version
        if self.transmission:
            attributes["transmission"] = self.transmission
        element = ElementTree.Element(type(self).__name__, attributes)

        return element


class Alignment(BaseNode):
    def __init__(
        self,
        geometry: Optional[str] = None,
        up: Optional[str] = "0,0,1",
        direction: Optional[str] = "0,0,-1",
        xml_node: Optional["Element"] = None,
        *args,
        **kwargs,
    ):
        self.geometry = geometry
        self.up = up
        self.direction = direction
        super().__init__(*args, **kwargs)

    def _read_xml(self, xml_node: "Element"):
        self.geometry = xml_node.attrib.get("geometry")
        self.up = xml_node.attrib.get("up", "0,0,1")
        self.direction = xml_node.attrib.get("direction", "0,0,-1")

    def __str__(self):
        return f"{self.geometry}"

    def to_xml(self):
        attributes = {}
        if self.geometry:
            attributes["geometry"] = self.geometry
        if self.up:
            attributes["up"] = self.up
        if self.direction:
            attributes["direction"] = self.direction
        element = ElementTree.Element(type(self).__name__, attributes)

        return element


class Overwrite(BaseNode):
    def __init__(
        self,
        universal: Optional[str] = None,
        target: Optional[str] = None,
        *args,
        **kwargs,
    ):
        self.universal = universal
        self.target = target
        super().__init__(*args, **kwargs)

    def _read_xml(self, xml_node: "Element"):
        self.universal = xml_node.attrib.get("universal")
        self.target = xml_node.attrib.get("target")

    def __str__(self):
        return f"{self.universal} {self.target}"

    def to_xml(self):
        attributes = {"universal": self.universal}
        if self.target:
            attributes["target"] = self.target
        element = ElementTree.Element(type(self).__name__, attributes)

        return element


class Connection(BaseNode):
    def __init__(
        self,
        own: Optional[str] = None,
        other: Optional[str] = None,
        to_object: Optional[str] = None,
        *args,
        **kwargs,
    ):
        self.own = own
        self.other = other
        self.to_object = to_object
        super().__init__(*args, **kwargs)

    def _read_xml(self, xml_node: "Element"):
        self.own = xml_node.attrib.get("own")
        self.other = xml_node.attrib.get("other")
        self.to_object = xml_node.attrib.get("toObject")

    def __str__(self):
        return f"{self.own} {self.other}"


class Mapping(BaseNode):
    def __init__(
        self,
        link_def: Optional[str] = None,
        ux: Optional[int] = None,
        uy: Optional[int] = None,
        ox: Optional[int] = None,
        oy: Optional[int] = None,
        rz: Optional[int] = None,
        *args,
        **kwargs,
    ):
        self.link_def = link_def
        self.ux = ux
        self.uy = uy
        self.ox = ox
        self.oy = oy
        self.rz = rz
        super().__init__(*args, **kwargs)

    def _read_xml(self, xml_node: "Element"):
        self.link_def = xml_node.attrib.get("linkedDef")
        self.ux = int(xml_node.find("ux").text)
        self.uy = int(xml_node.find("uy").text)
        self.ox = int(xml_node.find("ox").text)
        self.oy = int(xml_node.find("oy").text)
        self.rz = int(xml_node.find("rz").text)

    def __str__(self):
        return f"{self.link_def}"


class Gobo(BaseNode):
    def __init__(
        self,
        rotation: Union[str, float, None] = None,
        filename: Optional[None] = None,
        xml_node: Optional["Element"] = None,
        *args,
        **kwargs,
    ):
        self.rotation = rotation
        self.filename = filename
        super().__init__(*args, **kwargs)

    def _read_xml(self, xml_node: "Element"):
        self.rotation = float(xml_node.attrib.get("rotation", 0))
        self.filename = xml_node.text

    def __str__(self):
        return f"{self.filename} {self.rotation}"

    def to_xml(self):
        element = ElementTree.Element(type(self).__name__, rotation=str(self.rotation))
        element.text = self.filename

        return element


class CustomCommand(BaseNode):
    # TODO: split more: <CustomCommand>Body_Pan,f 50</CustomCommand>
    def __init__(
        self,
        custom_command: Optional[str] = None,
        xml_node: Optional["Element"] = None,
        *args,
        **kwargs,
    ):
        self.custom_command = custom_command
        super().__init__(*args, **kwargs)

    def _read_xml(self, xml_node: "Element"):
        self.custom_command = xml_node.text

    def __str__(self):
        return f"{self.custom_command}"

    def to_xml(self):
        element = ElementTree.Element(type(self).__name__)
        element.text = self.custom_command

        return element


class Projections(BaseNode):
    def __init__(
        self,
        projections: Optional[List["Projection"]] = None,
        xml_node: Optional["Element"] = None,
        *args,
        **kwargs,
    ):
        self.projections = projections if projections is not None else []
        super().__init__(xml_node, *args, **kwargs)

    def _read_xml(self, xml_node: "Element"):
        self.projections = [Projection(xml_node=i) for i in xml_node.findall("Projection")]

    def to_xml(self, parent: Element):
        element = ElementTree.SubElement(parent, type(self).__name__)
        for projection in self.projections:
            element.append(projection.to_xml())

        return element


class Source(BaseNode):
    def __init__(
        self,
        linked_geometry: Optional[str] = None,
        type_: Optional[str] = None,
        value: Optional[str] = None,
        xml_node: Optional["Element"] = None,
        *args,
        **kwargs,
    ):
        self.linked_geometry = linked_geometry
        self.type_ = type_
        self.value = value
        super().__init__(xml_node, *args, **kwargs)

    def _read_xml(self, xml_node: "Element"):
        self.linked_geometry = xml_node.attrib.get("linkedGeometry")
        self.type_ = xml_node.attrib.get("type")
        self.value = xml_node.text

    def __str__(self):
        return f"{self.linked_geometry} {self.type_}"

    def to_xml(self):
        attributes = {}
        if self.linked_geometry:
            attributes["linkedGeometry"] = self.linked_geometry
        if self.type_:
            attributes["type"] = self.type_
        element = ElementTree.Element(type(self).__name__, attributes)
        element.text = self.value

        return element


class Sources(BaseNode):
    def __init__(
        self,
        sources: Optional[List["Source"]] = None,
        xml_node: Optional["Element"] = None,
        *args,
        **kwargs,
    ):
        self.sources = sources if sources is not None else []
        super().__init__(xml_node, *args, **kwargs)

    def _read_xml(self, xml_node: "Element"):
        self.sources = [Source(xml_node=i) for i in xml_node.findall("Source")]

    def to_xml(self, parent: Element):
        element = ElementTree.SubElement(parent, type(self).__name__)
        for source in self.sources:
            element.append(source.to_xml())

        return element
